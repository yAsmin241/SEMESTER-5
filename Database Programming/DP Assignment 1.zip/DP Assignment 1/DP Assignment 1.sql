-- task 1
create database hostel_mgmt_yasminana;

use hostel_mgmt_yasminana;

create table room_types (
	type_id int auto_increment primary key,
    type_name varchar(50) not null unique,
	rent decimal(10, 2) not null,
	deposit decimal(10, 2) not null,
	capacity int not null
);

create table rooms (
	room_id int auto_increment primary key,
    room_no varchar(4) not null,
    floor_no int not null,
    is_occupied boolean,
    type_id int,
    foreign key (type_id) references room_types(type_id)
);

create table students (
	student_id int auto_increment primary key,
    fname varchar(50) not null,
    lname varchar(50) not null,
    status enum('ACTIVE', 'NON_ACTIVE') not null,
    checkin_date date not null,
    email varchar(100) not null,
    room_id int not null,
    foreign key (room_id) references rooms(room_id)
);

create table maintenance(
	maint_id int auto_increment primary key,
    issue_desc varchar(50),
    severity enum('LOW', 'MEDIUM', 'HIGH') not null,
    status enum('OPEN', 'RESOLVED') not null,
    reported_on date not null,
    resolved_on date not null,
    room_id int not null,
    foreign key (room_id) references rooms(room_id)
);

create table payments(
	payment_id int auto_increment primary key,
    amount decimal(10,2) not null,
    paid_on date not null,
    method enum('CASH', 'FPX', 'CARD', 'TNG') not null,
    note varchar(10) not null,
    student_id int,
    foreign key (student_id) references students(student_id)
);

alter table students 
modify column email varchar(100) unique;

drop table payments;

create table payments(
	payment_id int auto_increment primary key,
    amount decimal(10,2) not null,
    paid_on date not null,
    method enum('CASH', 'FPX', 'CARD', 'TNG') not null,
    note varchar(10) not null,
    student_id int,
    foreign key (student_id) references students(student_id)
);

-- task 2
insert into room_types (type_name, rent, deposit, capacity)
values ('Single Basic', 350.00, 200.00, 1), 
('Single Plus', 450.00, 220.00, 1), 
('Double Standard', 550.00, 300.00, 2), 
('Double Economy', 350.00, 200.00, 2),
('Premium Queen', 1000.00, 500.00, 2), 
('Premium King', 1200.00, 600.00, 2),
('Family Standard', 1400.00, 700.00, 4),
('Family Deluxe', 1600.00, 700.00, 4),
('Studio Compact', 800.00, 350.00, 1),
('Studio Loft', 900.00, 400.00, 2);

insert into rooms(room_no, floor_no, is_occupied)
values ('A101', 1, TRUE), 
('A102', 1, TRUE),
('A103', 1, FALSE),
('A104', 1, FALSE),
('A201', 2, TRUE),
('A202', 2, FALSE),
('A203', 2, FALSE),
('A301', 3, TRUE),
('A302', 3, TRUE),
('A303', 3, FALSE);

SELECT room_id, room_no FROM rooms;

UPDATE rooms
SET type_id = 1
WHERE room_id = 1;

UPDATE rooms
SET type_id = 2
WHERE room_id = 2;

UPDATE rooms
SET type_id = 3
WHERE room_id = 3;

UPDATE rooms
SET type_id = 4
WHERE room_id = 4;

UPDATE rooms
SET type_id = 5
WHERE room_id = 5;

UPDATE rooms
SET type_id = 6
WHERE room_id = 6;

UPDATE rooms
SET type_id = 7
WHERE room_id = 7;

UPDATE rooms
SET type_id = 8
WHERE room_id = 8;

UPDATE rooms
SET type_id = 9
WHERE room_id = 9;

UPDATE rooms
SET type_id = 10
WHERE room_id = 10;

insert into rooms(room_no, floor_no, is_occupied, type_id)
values ('A401', 4, TRUE, 1), 
('A402', 4, TRUE, 2),
('A403', 4, FALSE, 3),
('A501', 5, FALSE, 1),
('A502', 5, TRUE, 1);

select * from rooms;
select * from room_types;
select * from students;

insert into students (room_id, fname, lname, status, checkin_date, email)
values (4, 'Adibah', 'Noor', 'ACTIVE', '2023-11-01', 'adibah.noor@gmail.com'),
(1, 'Aryan', 'Nik', 'ACTIVE', '2022-10-21', 'nik_aryan@gmail.com'),
(2, 'Fahmi', 'Nazu', 'NON_ACTIVE', '2024-09-04', 'nazuFahmi@gmail.com'),
(6,'Kashwi', 'Verangan', 'ACTIVE', '2021-05-31', 'kashwi00@gmail.com'),
(9, 'Harry', 'Whistledown', 'NON_ACTIVE', '2022-04-28', 'sirHarry@gmail.com'),
(3, 'Dhea', 'Nang', 'ACTIVE', '2023-05-23', 'nang_dhea@gmail.com'),
(8, 'Yasmin', 'Hana', 'ACTIVE', '2021-07-10', 'princess.hana@gmail.com'),
(7, 'Asri', 'Faqih', 'NON_ACTIVE', '2024-12-02', '00asri00@gmail.com'),
(5,'Darwin', 'Khair', 'NON_ACTIVE', '2023-05-22', 'kingDarwin@gmail.com'),
(10, 'James', 'Fahrin', 'ACTIVE', '2021-01-15', 'james_fahrin@gmail.com');

update students set student_id = 101 where student_id = 1;
update students set student_id = 102 where student_id = 2;
update students set student_id = 103 where student_id = 3;
update students set student_id = 104 where student_id = 4;
update students set student_id = 105 where student_id = 5;
update students set student_id = 106 where student_id = 6;
update students set student_id = 107 where student_id = 7;
update students set student_id = 108 where student_id = 8;
update students set student_id = 109 where student_id = 9;
update students set student_id = 110 where student_id = 10;

alter table maintenance modify column resolved_on date null;

alter table payments modify column note varchar(100);

insert into payments(amount, paid_on, method, note, student_id)
values (350.00, '2025-10-26', 'CASH', 'october rent', 101),
(450.00, '2025-10-28', 'FPX', 'october rent', 102),
(550.00, '2025-10-25', 'CARD', 'october rent', 103),
(350.00, '2025-11-05', 'CASH', 'november rent', 104),
(1000.00, '2025-11-10', 'CASH', 'november rent', 105),
(1200.00, '2025-10-10', 'CARD', 'november rent', 106),
(700.00, '2025-10-05', 'TNG', 'october deposit', 107),
(1400.00, '2025-10-15', 'FPX', 'november rent', 108),
(350.00, '2025-11-02', 'CARD', 'november deposit', 109),
(400.00, '2025-11-07', 'FPX', 'november deposit', 110);

insert into maintenance (room_id, issue_desc, severity, status, reported_on, resolved_on)
values (1, 'Water Leak', 'LOW', 'RESOLVED', '2025-09-11', '2025-10-01'),
(2, 'No Electricity', 'HIGH', 'OPEN', '2025-10-12', '2025-10-12'),
(3, 'Flying Roof', 'HIGH', 'RESOLVED', '2025-09-17', '2025-11-09'),
(4, 'Ruptured Wall', 'MEDIUM', 'RESOLVED', '2025-11-01', '2025-11-12'),
(5, 'Burnt Lamp', 'LOW', 'RESOLVED', '2025-10-28', '2025-11-11'),
(6, 'Water Leak', 'HIGH', 'OPEN', '2025-05-12', '2025-06-12'),
(7, 'Flying Roof', 'MEDIUM', 'OPEN', '2025-07-15', '2025-07-15'),
(8, 'Flying Roof', 'HIGH', 'OPEN', '2025-06-12', '2025-06-12'),
(9, 'Ruptured Wall', 'LOW', 'RESOLVED', '2025-09-15', '2025-12-15'),
(10, 'Burnt Lamp', 'MEDIUM', 'RESOLVED', '2025-03-15', '2025-05-15');

SET SQL_SAFE_UPDATES = 0;

UPDATE rooms
SET is_occupied = CASE
    WHEN room_id IN (
        SELECT room_id
        FROM students
        WHERE status = 'ACTIVE'
    ) THEN 1
    ELSE 0
END;

SET SQL_SAFE_UPDATES = 1;

SET SQL_SAFE_UPDATES = 0;

DELETE FROM maintenance;

DELETE FROM maintenance
WHERE status = 'RESOLVED'
AND reported_on > (CURDATE() - INTERVAL 60 DAY);

select * from room_types where rent > 400 and rent < 800;

select * from students where fname like 'A%';

select * from payments where method in ('FPX', 'CARD');

select * from students
where (status = 'ACTIVE' and room_id = 1)
or
(status = 'NON-ACTIVE' and room_id = 2)
and not room_id = 10; 

select count(*) as total_students from students;

select MAX(rent) as HighestRent, MIN(rent) as LowestRent, avg(deposit) as avg_deposit, 
sum(capacity) as total_capacity from room_types;

select fName, UPPER(fName) as UpperFirstName from students;

select lName, LOWER(lName) as LowerLastName from students;

select fName, LENGTH(fName) as LengthFirstName from students;

select fName, lName,
CONCAT(fName, ' ', lName) as FullName from students;

create view v_room_status as
select 
	r.room_no,
    rt.type_name,
    rt.rent,
    r.floor_no,
    rt.capacity,
    sum(case when s.status = 'ACTIVE' then 1 else 0 end) as n_occupants,
    sum(case when m.status = 'OPEN' then 1 else 0 end) as pending_issues,
    case
		when sum(case when s.status = 'ACTIVE' then 1 else 0 end) = 0 
        then TRUE
        else FALSE
	end as is_vacant
from rooms r
left join room_types rt
	on r.type_id = rt.type_id
left join students s 
	on s.room_id = r.room_id
left join maintenance m
	on m.room_id = r.room_id
group by r.room_no,
    rt.type_name,
    rt.rent,
    r.floor_no,
    rt.capacity;
    
select 
	rt.type_name,
    count(s.student_id) as total_student
from room_types rt
left join rooms r
	on r.type_id = rt.type_id
left join students s 
	on s.room_id = r.room_id
group by rt.type_name; 

select 
	round(avg(rent),2) as Average_rent,
    round(sum(deposit),2) as total_deposit
from room_types; 

select
	year(paid_on) as year,
    month(paid_on) as month,
    sum(amount) as total_amount
from payments 
group by year(paid_on), month(paid_on)
order by year, month;

select 
	count(case when m.status='OPEN' then 1 end) as num_issues,
    r.floor_no
from maintenance m
left join rooms r
	on r.room_id = m.room_id
group by r.floor_no
having count(case when m.status='OPEN' then 1 end) > 2; 

SELECT 
    type_name,
    ROUND(rent, 2) AS rent_rounded
FROM room_types;

SELECT 
    r.room_no,
    ROUND(rt.rent, 2) AS rent_rounded,
    CONCAT('Room ', r.room_no, ' - ', rt.type_name) AS room_label,
    CASE
        WHEN rt.rent <= 100 THEN 'LOW'
        WHEN rt.rent <= 200 THEN 'MEDIUM'
        ELSE 'HIGH'
    END AS rent_category
FROM rooms r
JOIN room_types rt
    ON r.type_id = rt.type_id;
